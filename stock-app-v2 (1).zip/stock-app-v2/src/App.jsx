import React from 'react'

export default function App() {
  return (
    <div style={{ padding: 20 }}>
      <h1>📦 Stock App v2</h1>
      <p>매장 재고 관리 프로토타입입니다.</p>
      <ul>
        <li>👕 의류 랙: A</li>
        <li>👟 슈즈 랙: F</li>
      </ul>
    </div>
  )
}
