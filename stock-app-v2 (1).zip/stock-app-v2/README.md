# Stock App v2

매장 직원용 재고 관리 프로토타입입니다.  
PC/휴대폰에서 모두 접속 가능하며, GitHub와 Vercel을 통해 자동 배포됩니다.

---

## 🚀 설치 및 실행

### 로컬 실행 (개발용)
```bash
npm install
npm run dev
```
→ 브라우저에서 [http://localhost:5173](http://localhost:5173) 접속

### 네트워크 테스트 (PC ↔ 휴대폰)
```bash
npm run dev -- --host
```
→ 터미널에 표시된 `http://192.168.xxx.xxx:5173` 주소를 휴대폰 브라우저에서 열기

### 배포 (Vercel)
1. GitHub에 업로드
2. Vercel에서 GitHub Repo 연결
3. Framework: Vite → Deploy
4. 발급된 URL 접속

---

## 📂 폴더 구조
```
stock-app-v2/
 ┣ public/              # 정적 파일
 ┣ src/                 # React 소스코드
 ┣ index.html           # 앱 진입점
 ┣ package.json         # 의존성 및 스크립트
 ┣ vite.config.js       # Vite 설정
 ┗ README.md            # 설명 문서
```

---

## ✅ 체크리스트
- [ ] GitHub에 업로드 완료
- [ ] Vercel에서 Repo 연결 후 Deploy
- [ ] PC/휴대폰에서 접속 테스트
- [ ] 직원들과 URL 공유

---

💡 **코드 수정 후 GitHub에 push → Vercel 자동 배포**
